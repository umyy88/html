/* script.js - interactions: nav toggle, form validation, back-to-top, slideshow */
document.addEventListener('DOMContentLoaded', () => {
  // set copyright year
  document.getElementById('year').textContent = new Date().getFullYear();

  // NAV TOGGLE (mobile)
  const navToggle = document.getElementById('nav-toggle');
  const mainNav = document.getElementById('main-nav');

  navToggle.addEventListener('click', () => {
    mainNav.classList.toggle('open');
  });

  // CLOSE NAV on link click (mobile)
  mainNav.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => mainNav.classList.remove('open'));
  });

  // BACK TO TOP button
  const backToTop = document.getElementById('back-to-top');
  window.addEventListener('scroll', () => {
    if (window.scrollY > 300) backToTop.style.display = 'block';
    else backToTop.style.display = 'none';
  });
  backToTop.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  // SIMPLE FORM VALIDATION
  const form = document.getElementById('contact-form');
  const formMsg = document.getElementById('form-msg');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    formMsg.textContent = '';
    const name = form.name.value.trim();
    const email = form.email.value.trim();
    const message = form.message.value.trim();

    if (!name || !email || !message) {
      formMsg.textContent = 'Please fill all fields.';
      return;
    }
    // simple email pattern
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
      formMsg.textContent = 'Enter a valid email address.';
      return;
    }

    // If later you connect to PHP endpoint, you'd send data with fetch() here.
    formMsg.style.color = 'lightgreen';
    formMsg.textContent = 'Thanks — your message has been validated (demo).';
    form.reset();

    // reset message color after a while
    setTimeout(() => {
      formMsg.textContent = '';
      formMsg.style.color = '';
    }, 4000);
  });

  // SIMPLE SLIDESHOW
  const slidesContainer = document.getElementById('slides');
  const slides = slidesContainer ? slidesContainer.children : [];
  let current = 0;
  function goToSlide(i){
    if (!slidesContainer) return;
    current = (i + slides.length) % slides.length;
    slidesContainer.style.transform = `translateX(${-current * 100}%)`;
  }
  document.getElementById('prev-slide').addEventListener('click', () => goToSlide(current - 1));
  document.getElementById('next-slide').addEventListener('click', () => goToSlide(current + 1));

  // Auto-advance slideshow every 5s
  let slideInterval = setInterval(() => goToSlide(current + 1), 5000);
  // pause on hover
  slidesContainer.addEventListener('mouseenter', () => clearInterval(slideInterval));
  slidesContainer.addEventListener('mouseleave', () => slideInterval = setInterval(() => goToSlide(current + 1), 5000));

  // Smooth scroll for internal links
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', (e) => {
      // allow default anchor for top/back-to-top button
      const target = link.getAttribute('href');
      if (target && target !== '#') {
        e.preventDefault();
        const el = document.querySelector(target);
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

});
